//
//  AUUPlotView.h
//  AUUKit
//
//  Created by 胡金友 on 15/5/19.
//  Copyright (c) 2015年 胡金友. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView(AUUPlotView)

/**
 *  @author JyHu, 15-05-19 22:05:49
 *
 *  @brief  绘制直线
 *
 *  @param startPoint 起始点坐标
 *  @param endPoint   终止点坐标
 */
- (void)drawLineFrom:(CGPoint)startPoint to:(CGPoint)endPoint;

/**
 *  @author JyHu, 15-05-19 22:05:03
 *
 *  @brief  绘制矩形
 *
 *  @param rect  矩形的大小、位置
 *  @param model 线条类型
 */
- (void)drawRectangle:(CGRect)rect pathDrawingModel:(CGPathDrawingMode)model;

/**
 *  @author JyHu, 15-05-19 22:06:03
 *
 *  @brief  绘制圆角矩形
 *
 *  @param rect   矩形的大小、位置
 *  @param radius 圆角的弧度
 *  @param model  线条的类型
 */
- (void)drawRectangle:(CGRect)rect
           withRadius:(float)radius
     pathDrawingModel:(CGPathDrawingMode)model;

/**
 *  @author JyHu, 15-05-19 22:07:29
 *
 *  @brief  绘制多边形
 *
 *  @param pointArray 多边形的各个点的坐标
 *  @param model      线条的类型
 */
- (void)drawPolygon:(NSArray *)pointArray pathDrawingModel:(CGPathDrawingMode)model;

/**
 *  @author JyHu, 15-05-19 22:08:01
 *
 *  @brief  绘制圆形
 *
 *  @param center 圆形的圆心坐标
 *  @param radius 圆形的半径
 *  @param model  圆形线条的类型
 */
- (void)drawCircleWithCenter:(CGPoint)center
                      radius:(float)radius
            pathDrawingModel:(CGPathDrawingMode)model;

/**
 *  @author JyHu, 15-05-19 22:08:53
 *
 *  @brief  绘制三次贝塞尔曲线
 *
 *  @param startPoint    起始点坐标
 *  @param endPoint      终止点坐标
 *  @param controlPoint2 控制点1
 *  @param controlPoint2 控制点2
 *  @param model         线条类型
 */
- (void)drawCurveFrom:(CGPoint)startPoint
                   to:(CGPoint)endPoint
        controlPoint1:(CGPoint)controlPoint1
        controlPoint2:(CGPoint)controlPoint2
     pathDrawingModel:(CGPathDrawingMode)model;

/**
 *  @author JyHu, 15-05-19 22:10:07
 *
 *  @brief  绘制二次贝塞尔曲线
 *
 *  @param startPoint   开始坐标
 *  @param endPoint     结束坐标
 *  @param controlPoint 控制点
 *  @param model        绘制类型
 */
- (void)drawQuadCurveFrom:(CGPoint)startPoint
                       to:(CGPoint)endPoint
             controlPoint:(CGPoint)controlPoint
         pathDrawingModel:(CGPathDrawingMode)model;

/**
 *  @author JyHu, 15-05-19 22:11:17
 *
 *  @brief  绘制弧线
 *
 *  @param center     中心坐标
 *  @param radius     半径
 *  @param startAngle 开始的圆心角位置
 *  @param endAngle   结束的圆心角位置
 *  @param clockwise  clockwise description
 */
- (void)drawArcFromCenter:(CGPoint)center
                   radius:(float)radius
               startAngle:(float)startAngle
                 endAngle:(float)endAngle
                clockWise:(BOOL)clockwise;

/**
 *  @author JyHu, 15-05-19 22:13:12
 *
 *  @brief  绘制扇形
 *
 *  @param center     中心坐标
 *  @param radius     半径
 *  @param startAngle 开始的圆心坐标
 *  @param endAngle   结束的圆心坐标
 *  @param clockWise  clockWise description
 *  @param model      绘图的方式
 */
- (void)drawSectorFromCenter:(CGPoint)center
                      radius:(float)radius
                  startAngle:(float)startAngle
                    endAngle:(float)endAngle
                   clockWise:(BOOL)clockWise
            pathDrawingModel:(CGPathDrawingMode)model;

/**
 *  @author JyHu, 15-05-19 22:15:03
 *
 *  @brief  绘制多点折线
 *
 *  @param pointArray 折线转折点坐标
 */
- (void)drawLines:(NSArray *)pointArray;

/**
 *  @author JyHu, 15-05-19 22:16:43
 *
 *  @brief  绘制渐变色块
 */
- (void)drawShadowColor;

@end
